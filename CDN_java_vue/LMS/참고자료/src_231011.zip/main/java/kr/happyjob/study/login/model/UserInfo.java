package kr.happyjob.study.login.model;

public class UserInfo {
	
/*		loginID
	,	user_type
	,	name
	,	password
	,	email_cop
	,	birthday
	,	gender_cd
	,	user_tel1
	,	user_tel2
	,	user_tel3
	,	user_zipcode
	,	user_address
	,	user_dt_address
,	consult_yn
	,	del_cd
	,	div_cd
	,	user_email
	,	user_company
	,	approval_cd*/
	private String loginID;
	private String user_type;
	private String name;
	private String password;
	private String email_cop;
	private String birthday;
	private String gender_cd;
	private String tel1;
	private String tel2;
	private String tel3;
	private String user_zipcode;
	private String user_address;
	private String user_dt_address;
 	private String consult_yn;
	private String del_cd;
	private String div_cd;
	private String user_email;
	private String user_company;
	private String approval_cd;
	private	String salary;
	private	String career_yn;
	private	String career_mm;
	private	String user_grade;
	private	String user_hope_area1;
	private	String user_hope_area2;
	private	String user_hope_area3;
	
	
	public String getUser_grade() {
		return user_grade;
	}
	public void setUser_grade(String user_grade) {
		this.user_grade = user_grade;
	}
	public String getUser_hope_area1() {
		return user_hope_area1;
	}
	public void setUser_hope_area1(String user_hope_area1) {
		this.user_hope_area1 = user_hope_area1;
	}
	public String getUser_hope_area2() {
		return user_hope_area2;
	}
	public void setUser_hope_area2(String user_hope_area2) {
		this.user_hope_area2 = user_hope_area2;
	}
	public String getUser_hope_area3() {
		return user_hope_area3;
	}
	public void setUser_hope_area3(String user_hope_area3) {
		this.user_hope_area3 = user_hope_area3;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getUser_type() {
		return user_type;
	}
	public void setUser_type(String user_type) {
		this.user_type = user_type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getEmail_cop() {
		return email_cop;
	}
	public void setEmail_cop(String email_cop) {
		this.email_cop = email_cop;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getGender_cd() {
		return gender_cd;
	}
	public void setGender_cd(String gender_cd) {
		this.gender_cd = gender_cd;
	}
	public String getTel1() {
		return tel1;
	}
	public void setTel1(String tel1) {
		this.tel1 = tel1;
	}
	public String getTel2() {
		return tel2;
	}
	public void setTel2(String tel2) {
		this.tel2 = tel2;
	}
	public String getTel3() {
		return tel3;
	}
	public void setTel3(String tel3) {
		this.tel3 = tel3;
	}
	public String getUser_zipcode() {
		return user_zipcode;
	}
	public void setUser_zipcode(String user_zipcode) {
		this.user_zipcode = user_zipcode;
	}
	public String getUser_address() {
		return user_address;
	}
	public void setUser_address(String user_address) {
		this.user_address = user_address;
	}
	public String getUser_dt_address() {
		return user_dt_address;
	}
	public void setUser_dt_address(String user_dt_address) {
		this.user_dt_address = user_dt_address;
	}
	public String getConsult_yn() {
		return consult_yn;
	}
	public void setConsult_yn(String consult_yn) {
		this.consult_yn = consult_yn;
	}
	public String getDel_cd() {
		return del_cd;
	}
	public void setDel_cd(String del_cd) {
		this.del_cd = del_cd;
	}
	public String getDiv_cd() {
		return div_cd;
	}
	public void setDiv_cd(String div_cd) {
		this.div_cd = div_cd;
	}
	public String getUser_email() {
		return user_email;
	}
	public void setUser_email(String user_email) {
		this.user_email = user_email;
	}
	public String getUser_company() {
		return user_company;
	}
	public void setUser_company(String user_company) {
		this.user_company = user_company;
	}
	public String getApproval_cd() {
		return approval_cd;
	}
	public void setApproval_cd(String approval_cd) {
		this.approval_cd = approval_cd;
	}
	public String getSalary() {
		return salary;
	}
	public void setSalary(String salary) {
		this.salary = salary;
	}
	public String getCareer_yn() {
		return career_yn;
	}
	public void setCareer_yn(String career_yn) {
		this.career_yn = career_yn;
	}
	public String getCareer_mm() {
		return career_mm;
	}
	public void setCareer_mm(String career_mm) {
		this.career_mm = career_mm;
	}
	
	
	
}
