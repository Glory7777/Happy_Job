package kr.happyjob.study.mngadm.model;

public class AdviceLecModel {


	
	// tb_lec
	private int lec_cd;				//강의코드
	private String lec_nm;			//수강강의명
	private String ins_id;			//강사ID
	private String lec_start_date;		//강의시작일
	private String lec_end_date;		//강의종료일
		
	// tb_userinfo
	private String ins_nm; 	//강사명

	public int getLec_cd() {
		return lec_cd;
	}

	public void setLec_cd(int lec_cd) {
		this.lec_cd = lec_cd;
	}

	public String getLec_nm() {
		return lec_nm;
	}

	public void setLec_nm(String lec_nm) {
		this.lec_nm = lec_nm;
	}

	public String getIns_id() {
		return ins_id;
	}

	public void setIns_id(String ins_id) {
		this.ins_id = ins_id;
	}

	public String getLec_start_date() {
		return lec_start_date;
	}

	public void setLec_start_date(String lec_start_date) {
		this.lec_start_date = lec_start_date;
	}

	public String getLec_end_date() {
		return lec_end_date;
	}

	public void setLec_end_date(String lec_end_date) {
		this.lec_end_date = lec_end_date;
	}

	public String getIns_nm() {
		return ins_nm;
	}

	public void setIns_nm(String ins_nm) {
		this.ins_nm = ins_nm;
	}
}
