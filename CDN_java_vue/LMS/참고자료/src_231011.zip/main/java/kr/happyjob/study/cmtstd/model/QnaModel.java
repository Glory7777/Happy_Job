package kr.happyjob.study.cmtstd.model;

import java.util.Date;

public class QnaModel {

   private int brd_no;              		//글번호
   private String brd_title;         	//제목
   private String brd_ctt;            	//내용
   private String brd_wt;            	//직상지      
   private String loginID;            	//작성자id
   private String brd_reg_date;     //등록일
   private int brd_veiws_cnt;        //조회수
   private String brd_delete_yn;    //삭제여부
   private int ctg_cd;               		//분류코드
   private String reply_ctt;            //답글
   private String ans_yn;				//답변유무
   
   
   public String getAns_yn() {
		return ans_yn;
	}
	public void setAns_yn(String ans_yn) {
		this.ans_yn = ans_yn;
	}
//답변테이블
   private String reg_date;

   private String name;
   
   private int reply_no;
   
   public String getReply_ctt() {
      return reply_ctt;
   }
   public void setReply_ctt(String reply_ctt) {
      this.reply_ctt = reply_ctt;
   }
   public int getReply_no() {
      return reply_no;
   }
   public void setReply_no(int reply_no) {
      this.reply_no = reply_no;
   }
   public String getReg_date() {
      return reg_date;
   }
   public void setReg_date(String reg_date) {
      this.reg_date = reg_date;
   }

   public String getName() {
      return name;
   }
   public void setName(String name) {
      this.name = name;
   }
   public int getBrd_no() {
      return brd_no;
   }
   public void setBrd_no(int brd_no) {
      this.brd_no = brd_no;
   }
   public String getBrd_title() {
      return brd_title;
   }
   public void setBrd_title(String brd_title) {
      this.brd_title = brd_title;
   }
   public String getBrd_ctt() {
      return brd_ctt;
   }
   public void setBrd_ctt(String brd_ctt) {
      this.brd_ctt = brd_ctt;
   }
   public String getBrd_wt() {
      return brd_wt;
   }
   public void setBrd_wt(String brd_wt) {
      this.brd_wt = brd_wt;
   }
   public String getLoginID() {
      return loginID;
   }
   public void setLoginID(String loginID) {
      this.loginID = loginID;
   }
   public String getBrd_reg_date() {
      return brd_reg_date;
   }
   public void setBrd_reg_date(String brd_reg_date) {
      this.brd_reg_date = brd_reg_date;
   }
   public int getBrd_veiws_cnt() {
      return brd_veiws_cnt;
   }
   public void setBrd_veiws_cnt(int brd_veiws_cnt) {
      this.brd_veiws_cnt = brd_veiws_cnt;
   }
   public String getBrd_delete_yn() {
      return brd_delete_yn;
   }
   public void setBrd_delete_yn(String brd_delete_yn) {
      this.brd_delete_yn = brd_delete_yn;
   }
   public int getCtg_cd() {
      return ctg_cd;
   }
   public void setCtg_cd(int ctg_cd) {
      this.ctg_cd = ctg_cd;
   }

   
   
}