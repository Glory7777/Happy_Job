var now = new Date();

console.log("date::: " + now.getFullYear);

