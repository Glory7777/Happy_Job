package kr.happyjob.study.sptadm.model;

public class NtModel {
	
	// 게시판 글 번호
	private String brd_no;
    private String brd_title;
    private String brd_ctt;
    private String brd_wt;
    private String loginID;
	private String brd_reg_date;
	private int brd_veiws_cnt;
	private String brd_delete_yn;
	private String ctg_cd;
	
	
	public String getBrd_no() {
		return brd_no;
	}
	public void setBrd_no(String brd_no) {
		this.brd_no = brd_no;
	}
	public String getBrd_title() {
		return brd_title;
	}
	public void setBrd_title(String brd_title) {
		this.brd_title = brd_title;
	}
	public String getBrd_ctt() {
		return brd_ctt;
	}
	public void setBrd_ctt(String brd_ctt) {
		this.brd_ctt = brd_ctt;
	}
	public String getBrd_wt() {
		return brd_wt;
	}
	public void setBrd_wt(String brd_wt) {
		this.brd_wt = brd_wt;
	}
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getBrd_reg_date() {
		return brd_reg_date;
	}
	public void setBrd_reg_date(String brd_reg_date) {
		this.brd_reg_date = brd_reg_date;
	}
	public int getBrd_veiws_cnt() {
		return brd_veiws_cnt;
	}
	public void setBrd_veiws_cnt(int brd_veiws_cnt) {
		this.brd_veiws_cnt = brd_veiws_cnt;
	}
	public String getBrd_delete_yn() {
		return brd_delete_yn;
	}
	public void setBrd_delete_yn(String brd_delete_yn) {
		this.brd_delete_yn = brd_delete_yn;
	}
	public String getCtg_cd() {
		return ctg_cd;
	}
	public void setCtg_cd(String ctg_cd) {
		this.ctg_cd = ctg_cd;
	}

	
	

}
