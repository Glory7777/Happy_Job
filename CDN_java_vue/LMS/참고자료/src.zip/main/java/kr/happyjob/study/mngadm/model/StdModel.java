package kr.happyjob.study.mngadm.model;

public class StdModel {
	
	private String loginId;		// 학생ID
	private String name;		// 학생 이름
	private String hp;			// 학생 연락처
	private String email;		// 학생 이메일
	private int lec_cd;			// 강의 코드
	private String lec_nm;		// 과목(강의명)
	
	
	
	public String getLoginId() {
		return loginId;
	}
	public void setLoginId(String loginId) {
		this.loginId = loginId;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getHp() {
		return hp;
	}
	public void setHp(String hp) {
		this.hp = hp;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getLec_cd() {
		return lec_cd;
	}
	public void setLec_cd(int lec_cd) {
		this.lec_cd = lec_cd;
	}
	public String getLec_nm() {
		return lec_nm;
	}
	public void setLec_nm(String lec_nm) {
		this.lec_nm = lec_nm;
	}
	
	
}
