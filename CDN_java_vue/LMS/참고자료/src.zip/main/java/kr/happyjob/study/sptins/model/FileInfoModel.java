package kr.happyjob.study.sptins.model;

public class FileInfoModel {
	
	// tb_lec_file
	private int lec_file_no;					// 등록번호
	private String lec_file_upload_date;		// 등록일자
	private String lec_file_ctt;				// 자료내용
	private String lec_file_path;				// 파일경로
	private String lec_file_nm;					// 파일명
	private int lec_file_size;					// 파일사이즈
	private String lec_file_extend;				// 파일확장자
	private String lec_file_logical;			// 논리경로
	
	
	
	
	public int getLec_file_no() {
		return lec_file_no;
	}
	public void setLec_file_no(int lec_file_no) {
		this.lec_file_no = lec_file_no;
	}
	public String getLec_file_upload_date() {
		return lec_file_upload_date;
	}
	public void setLec_file_upload_date(String lec_file_upload_date) {
		this.lec_file_upload_date = lec_file_upload_date;
	}
	public String getLec_file_ctt() {
		return lec_file_ctt;
	}
	public void setLec_file_ctt(String lec_file_ctt) {
		this.lec_file_ctt = lec_file_ctt;
	}
	public String getLec_file_path() {
		return lec_file_path;
	}
	public void setLec_file_path(String lec_file_path) {
		this.lec_file_path = lec_file_path;
	}
	public String getLec_file_nm() {
		return lec_file_nm;
	}
	public void setLec_file_nm(String lec_file_nm) {
		this.lec_file_nm = lec_file_nm;
	}
	public int getLec_file_size() {
		return lec_file_size;
	}
	public void setLec_file_size(int lec_file_size) {
		this.lec_file_size = lec_file_size;
	}
	public String getLec_file_extend() {
		return lec_file_extend;
	}
	public void setLec_file_extend(String lec_file_extend) {
		this.lec_file_extend = lec_file_extend;
	}
	public String getLec_file_logical() {
		return lec_file_logical;
	}
	public void setLec_file_logical(String lec_file_logical) {
		this.lec_file_logical = lec_file_logical;
	}
	
	
	
	
	
}






