package kr.happyjob.study.consupport.model;

import java.util.Date;

public class NameListModel {

	//로그인 아이디
	private String loginID;
	//유저 이름
	private String name;
	//희망 연봉
	private int user_salary;
	// 등급
	private String user_grade;
	// 전문기술
	private String user_hope_work;
	// 제목
	private String user_describe;
	
	public String getLoginID() {
		return loginID;
	}
	public void setLoginID(String loginID) {
		this.loginID = loginID;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getUser_salary() {
		return user_salary;
	}
	public void setUser_salary(int user_salary) {
		this.user_salary = user_salary;
	}
	public String getUser_grade() {
		return user_grade;
	}
	public void setUser_grade(String user_grade) {
		this.user_grade = user_grade;
	}
	public String getUser_hope_work() {
		return user_hope_work;
	}
	public void setUser_hope_work(String user_hope_work) {
		this.user_hope_work = user_hope_work;
	}
	public String getUser_describe() {
		return user_describe;
	}
	public void setUser_describe(String user_describe) {
		this.user_describe = user_describe;
	}	
	
	
	
	
	
	
	
	

}
