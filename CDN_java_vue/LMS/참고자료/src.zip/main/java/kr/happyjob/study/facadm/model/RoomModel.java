package kr.happyjob.study.facadm.model;

public class RoomModel {
	private int cls_room_cd;
	private String cls_room_nm;
	private int cls_room_size;
	private int cls_room_seat;
	private String cls_room_etc;
	private String cls_room_use_yn;
	
	
	public int getCls_room_cd() {
		return cls_room_cd;
	}
	public void setCls_room_cd(int cls_room_cd) {
		this.cls_room_cd = cls_room_cd;
	}
	public String getCls_room_nm() {
		return cls_room_nm;
	}
	public void setCls_room_nm(String cls_room_nm) {
		this.cls_room_nm = cls_room_nm;
	}
	public int getCls_room_size() {
		return cls_room_size;
	}
	public void setCls_room_size(int cls_room_size) {
		this.cls_room_size = cls_room_size;
	}
	public int getCls_room_seat() {
		return cls_room_seat;
	}
	public void setCls_room_seat(int cls_room_seat) {
		this.cls_room_seat = cls_room_seat;
	}
	public String getCls_room_etc() {
		return cls_room_etc;
	}
	public void setCls_room_etc(String cls_room_etc) {
		this.cls_room_etc = cls_room_etc;
	}
	public String getCls_room_use_yn() {
		return cls_room_use_yn;
	}
	public void setCls_room_use_yn(String cls_room_use_yn) {
		this.cls_room_use_yn = cls_room_use_yn;
	}


}
