package kr.happyjob.study.facadm.model;

public class EquModel {
	
	private int equ_cd;
	private String equ_nm;
	private int equ_total_cnt;
	private int equ_use_cnt;
	private int equ_unable_cnt;
	private int equ_able_cnt;
	private String equ_etc;

    public int getEqu_cd() {
		return equ_cd;
	}
	public void setEqu_cd(int equ_cd) {
		this.equ_cd = equ_cd;
	}
	public String getEqu_nm() {
		return equ_nm;
	}
	public void setEqu_nm(String equ_nm) {
		this.equ_nm = equ_nm;
	}
	public int getEqu_total_cnt() {
		return equ_total_cnt;
	}
	public void setEqu_total_cnt(int equ_total_cnt) {
		this.equ_total_cnt = equ_total_cnt;
	}
	public int getEqu_use_cnt() {
		return equ_use_cnt;
	}
	public void setEqu_use_cnt(int equ_use_cnt) {
		this.equ_use_cnt = equ_use_cnt;
	}
	public int getEqu_unable_cnt() {
		return equ_unable_cnt;
	}
	public void setEqu_unable_cnt(int equ_unable_cnt) {
		this.equ_unable_cnt = equ_unable_cnt;
	}
	public int getEqu_able_cnt() {
		return equ_able_cnt;
	}
	public void setEqu_able_cnt(int equ_able_cnt) {
		this.equ_able_cnt = equ_able_cnt;
	}
	public String getEqu_etc() {
		return equ_etc;
	}
	public void setEqu_etc(String equ_etc) {
		this.equ_etc = equ_etc;
	}

}
